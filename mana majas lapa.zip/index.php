<?php include 'header.php' ?>
<?php include 'produkts.php' ?>
    <form method="post">
    <input type="text" name="Produkta_Nos" id="Produkta_Nos" placeholder="Product">
    <input type="text" name="Produkta_Text" id="Produkta_Text" placeholder = "Produkta apraksts">
    <input type="text" name="Produkta_Bilde" id="Produkta_Bilde" placeholder="Produkta attēls">
    <input type="text" name="Produkta_Cena" id="Produkta_Cena" placeholder = "Produkta cena">
    <input type="text" name="Produkta_Skaits" id="Produkta_Skaits" placeholder="Produktu daudzums">

    <input type="submit" name="submit" value="Saglabāt">
</form>