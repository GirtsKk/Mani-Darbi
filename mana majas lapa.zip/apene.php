<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<meta name="viewport" content="width=device-width, initial-scale=1">

<?php
include 'insert.php';
?>

</head>
<body>
        <form method="post">
                <input type="text" name="Students" id="Students" placeholder="Vārds, Uzvards">
                <input type="submit" value="ievietot">
        </form>
</body>

</html
